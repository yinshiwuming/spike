//
//  buymyViewController.h
//  spike
//
//  Created by 泽联教育 on 2018/4/19.
//  Copyright © 2018年 泽联教育. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface buymyViewController : UIViewController

@end
