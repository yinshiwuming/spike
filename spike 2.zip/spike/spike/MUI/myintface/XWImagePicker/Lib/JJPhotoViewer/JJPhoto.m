//
//  JJPhoto.m
//  test
//
//  Created by mac on 2016/11/25.
//  Copyright © 2016年 com.rongniu.caifuwang. All rights reserved.
//
#import "JJPhoto.h"

@implementation JJPhoto

@end
