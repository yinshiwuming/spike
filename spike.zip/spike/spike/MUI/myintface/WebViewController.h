//
//  WebViewController.h
//  spike
//
//  Created by 泽联教育 on 2018/4/8.
//  Copyright © 2018年 泽联教育. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "invitationViewController.h"
@interface WebViewController : UIViewController<UIWebViewDelegate>

@end
