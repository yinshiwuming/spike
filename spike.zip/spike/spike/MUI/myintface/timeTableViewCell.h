//
//  timeTableViewCell.h
//  spike
//
//  Created by 泽联教育 on 2018/4/16.
//  Copyright © 2018年 泽联教育. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "timeTableViewCell.h"
#import "celldata.h"
@interface timeTableViewCell : UITableViewCell
@property(nonatomic,strong)celldata*celldata;
@end
