//
//  HavTableViewCell.h
//  spike
//
//  Created by 泽联教育 on 2018/3/28.
//  Copyright © 2018年 泽联教育. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HavTableViewCell : UITableViewCell
@property (nonatomic, strong) UILabel *leftLabel;
// 电话号码的label

@end
