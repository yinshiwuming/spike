//
//  MFlowLayOut.h
//  QQImagePicker
//
//  Created by mac on 2016/11/25.
//  Copyright © 2016年 com.rongniu.caifuwang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MFlowLayOut : UICollectionViewFlowLayout

@end
