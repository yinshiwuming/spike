//
//  Define.h
//  QQImagePicker
//
//  Created by mac on 2016/11/25.
//  Copyright © 2016年 com.rongniu.caifuwang. All rights reserved.
//

#ifndef QQImagePicker_Define_h
#define QQImagePicker_Define_h

typedef void (^MBasicBlock)();
typedef void (^MIndexBlock)(int index);
typedef void (^MobjBlock)(id obj);
typedef void (^MBoolBlock)(BOOL state);

#endif
